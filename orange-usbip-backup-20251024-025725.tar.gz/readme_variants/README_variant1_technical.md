# Orange USB/IP Web Interface

## Описание проекта

Комплексный веб-интерфейс для управления USB/IP устройствами, разработанный для надежной конфигурации, мониторинга и расширенной системной диагностики на Linux платформах.

## Ключевые возможности

- 🔌 Управление USB устройствами через USB/IP протокол
- 🌐 Веб-интерфейс для удаленного управления устройствами
- 📊 Мониторинг локальных и удаленных USB устройств в реальном времени
- 🔐 Система аутентификации и управления пользователями
- 🌍 Поддержка русского и английского языков
- 💾 Виртуальные USB устройства с управлением файлами
- 🛠️ Встроенная система диагностики
- 📱 Адаптивный интерфейс на базе Bootstrap

## Архитектура проекта

### Основные компоненты

- **Flask Application** (`app.py`) - Основное веб-приложение с аутентификацией
- **Database Models** (`models.py`) - SQLAlchemy модели для пользователей, устройств, логов
- **USB/IP Utilities** (`usbip_utils.py`) - Функции управления USB/IP устройствами
- **Virtual Storage** (`virtual_storage_utils.py`) - Управление файлами виртуальных USB устройств
- **Translation System** (`translations.py`) - Система многоязычной поддержки

### Технологический стек

- **Backend**: Flask, Flask-Login, SQLAlchemy
- **Frontend**: Bootstrap 5, JavaScript (без фреймворков)
- **Database**: PostgreSQL / SQLite
- **Icons**: Font Awesome, кастомные SVG иконки
- **USB/IP**: Linux kernel USB/IP drivers

## Установка

### Debian/Ubuntu (x86_64 и ARM)

```bash
curl -fsSL https://raw.githubusercontent.com/maksfaktor/usbip-web/main/install_debian.sh -o install_debian.sh
chmod +x install_debian.sh
sudo ./install_debian.sh
```

### ARM платформы (Orange Pi, Raspberry Pi)

```bash
curl -fsSL https://raw.githubusercontent.com/maksfaktor/usbip-web/main/install_arm.sh -o install_arm.sh
chmod +x install_arm.sh
sudo ./install_arm.sh
```

## Использование

После установки веб-интерфейс доступен по адресу:
```
http://ваш-ip:5000
```

Данные для входа по умолчанию:
- **Логин**: admin
- **Пароль**: admin123

⚠️ **Важно**: Измените пароль администратора после первого входа!

## Основные функции

### Публикация USB устройств

1. Откройте страницу "Local USB Devices"
2. Найдите нужное устройство в списке
3. Нажмите кнопку "Publish Device"
4. Устройство станет доступно для удаленного подключения

### Отмена публикации

1. Найдите опубликованное устройство (помечено зеленым статусом)
2. Нажмите желтую кнопку "Cancel"
3. Устройство будет отключено от USB/IP

### Подключение к удаленным устройствам

1. Перейдите на страницу "Remote USB Devices"
2. Введите IP адрес удаленного сервера
3. Выберите устройство из списка
4. Нажмите "Attach Device"

## Диагностика

Для проверки состояния системы используйте встроенный диагностический скрипт:

```bash
sudo ./doctor.sh
```

Скрипт проверяет:
- Статус USB/IP модулей ядра
- Состояние служб usbipd и orange-usbip
- Список подключенных USB устройств
- Опубликованные устройства
- Логи системы

## Удаление

### Интерактивное удаление

```bash
curl -fsSL https://raw.githubusercontent.com/maksfaktor/usbip-web/main/check_and_remove.sh -o check_and_remove.sh
chmod +x check_and_remove.sh
sudo ./check_and_remove.sh
```

### Полное удаление

```bash
sudo ./uninstall.sh
```

## Структура файлов

```
├── app.py                      # Главное Flask приложение
├── models.py                   # Модели базы данных
├── usbip_utils.py             # Утилиты USB/IP
├── virtual_storage_utils.py   # Управление виртуальными устройствами
├── translations.py            # Система переводов
├── templates/                 # HTML шаблоны
│   ├── base.html             # Базовый шаблон
│   ├── login.html            # Страница входа
│   ├── index.html            # Главная страница
│   ├── local_devices.html    # Локальные устройства
│   ├── remote_devices.html   # Удаленные устройства
│   └── terminal.html         # Веб-терминал
├── static/                    # Статические файлы
│   ├── orange-icon.svg       # Иконка приложения
│   └── ...
├── install_debian.sh         # Установочный скрипт Debian/Ubuntu
├── install_arm.sh           # Установочный скрипт ARM
├── uninstall.sh            # Скрипт удаления
└── doctor.sh               # Диагностический скрипт
```

## Разработка

### Установка зависимостей для разработки

```bash
pip install -r requirements-deploy.txt
```

### Запуск в режиме разработки

```bash
export DATABASE_URL="sqlite:///usbip_web.db"
export SESSION_SECRET="your-secret-key"
python main.py
```

### Структура базы данных

- **User**: Пользователи системы
- **Device**: USB устройства
- **DeviceLog**: Логи операций с устройствами
- **TerminalCommand**: Команды для веб-терминала

## Безопасность

- Использует Flask-Login для управления сессиями
- Пароли хешируются с использованием Werkzeug
- Поддержка HTTPS через прокси (ProxyFix)
- Изоляция прав доступа через systemd

## Поддержка

- **GitHub**: https://github.com/maksfaktor/usbip-web
- **Issues**: https://github.com/maksfaktor/usbip-web/issues

## Лицензия

MIT License

## Благодарности

Разработано для Orange Pi и других ARM платформ с поддержкой USB/IP.
